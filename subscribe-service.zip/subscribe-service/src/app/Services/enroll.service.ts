export class EnrollService{
    OnEnrollClicked(title: string){
        alert('Thank you for enrolling to '+title+' course.');
    }
}