export class Customer {
    customerNo: number;
    name:string ;
    address:string;
    city:string;
    country:string;   
}