export class Product{
    pName: string;
    desc: string;
    price: string
    id?: string;
}